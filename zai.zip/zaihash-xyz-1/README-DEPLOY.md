# Crypto Airdrop Platform - VPS Deployment

## Quick Start

Deploy to any Ubuntu/Debian VPS with one command:

```bash
# Clone and deploy
git clone <your-repo-url>
cd crypto-airdrop-platform
chmod +x deploy-vps.sh
./deploy-vps.sh
```

## Requirements

- Ubuntu 20.04+ or Debian 11+ VPS
- 2GB+ RAM, 20GB+ storage
- SSH access with sudo privileges
- Ports 22, 80, 443 open

## What Gets Installed

- Node.js 20 + PM2 process manager
- PostgreSQL database with secure user
- Nginx reverse proxy with security headers
- UFW firewall configuration
- SSL-ready setup
- Automated backup system
- Management tools

## Management

After deployment, use the management script:

```bash
cd /var/www/crypto-airdrop

# Check status and logs
./manage.sh status
./manage.sh health
./manage.sh logs

# Application control
./manage.sh start
./manage.sh stop
./manage.sh restart

# Maintenance
./manage.sh backup
./manage.sh update
./manage.sh restore /path/to/backup.sql

# SSL setup
./manage.sh ssl yourdomain.com
```

## Security Notes

- Default admin credentials: admin/admin123
- Change these immediately after first login
- Set up SSL for production use
- Monitor logs regularly
- Keep system updated

## Troubleshooting

**Application won't start:**
```bash
./manage.sh status
pm2 logs crypto-airdrop
```

**Database issues:**
```bash
sudo systemctl status postgresql
sudo -u postgres psql -l
```

**Web server problems:**
```bash
sudo systemctl status nginx
sudo nginx -t
```

**Build failures:**
- Ensure 2GB+ RAM available
- Check disk space
- Monitor build output for specific errors

## Architecture

- **Frontend:** React + Vite (port 5000 via Nginx)
- **Backend:** Express.js + TypeScript
- **Database:** PostgreSQL with connection pooling
- **Process Manager:** PM2 with auto-restart
- **Web Server:** Nginx reverse proxy
- **Security:** UFW firewall, security headers