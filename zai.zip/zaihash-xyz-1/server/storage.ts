import { db } from "@db";
import { 
  users, 
  airdrops, 
  newsletters,
  categories,
  siteSettings,
  creatorApplications,
  User,
  Airdrops,
  InsertAirdrops,
  Category,
  InsertCategory,
  SiteSettings,
  InsertSiteSettings,
  CreatorApplication,
  InsertCreatorApplication,
  Newsletter
} from "@shared/schema";
import { eq, and, desc, or } from "drizzle-orm";
import session from "express-session";
import { randomBytes } from "crypto";

export interface IStorage {
  // User methods
  getUser(id: number): Promise<User>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByWalletAddress(address: string): Promise<User | undefined>;
  getAllUsers(): Promise<User[]>;
  createUser(user: any): Promise<User>;
  createUserWithPassword(userData: { username: string; password: string; isAdmin: boolean }): Promise<User>;
  updateUser(id: number, data: Partial<User>): Promise<User>;
  updateUserPassword(id: number, currentPassword: string, newPassword: string): Promise<boolean>;
  generateNonce(wallet: string): Promise<string>;
  promoteToCreator(userId: number): Promise<User>;
  revokeCreatorStatus(userId: number): Promise<User>;
  
  // Airdrop methods
  getAllAirdrops(): Promise<Airdrops[]>;
  getAirdropsByCategory(categoryId: number): Promise<Airdrops[]>;
  getFeaturedAirdrops(limit?: number): Promise<Airdrops[]>;
  getAirdropById(id: number): Promise<Airdrops | undefined>;
  createAirdrop(airdrop: InsertAirdrops): Promise<Airdrops>;
  updateAirdrop(id: number, data: Partial<InsertAirdrops>): Promise<Airdrops | undefined>;
  deleteAirdrop(id: number): Promise<void>;
  incrementAirdropViews(id: number): Promise<void>;
  
  // Category methods
  getAllCategories(): Promise<Category[]>;
  getCategoryById(id: number): Promise<Category | undefined>;
  createCategory(category: InsertCategory): Promise<Category>;
  updateCategory(id: number, data: Partial<Category>): Promise<Category | undefined>;
  deleteCategory(id: number): Promise<void>;
  
  // Site Settings methods
  getSiteSettings(): Promise<SiteSettings>;
  updateSiteSettings(data: Partial<SiteSettings>): Promise<SiteSettings>;
  
  // User-Airdrop interactions
  toggleSavedAirdrop(userId: number, airdropId: number): Promise<void>;
  toggleCompletedAirdrop(userId: number, airdropId: number): Promise<void>;
  
  // Newsletter
  subscribeToNewsletter(email: string): Promise<void>;
  getNewsletterSubscribers(): Promise<Newsletter[]>;
  
  // Creator Applications
  getCreatorApplications(): Promise<CreatorApplication[]>;
  getUserCreatorApplications(userId: number): Promise<CreatorApplication[]>;
  getCreatorApplicationById(id: number): Promise<CreatorApplication | undefined>;
  createCreatorApplication(application: InsertCreatorApplication): Promise<CreatorApplication>;
  updateCreatorApplication(id: number, data: Partial<CreatorApplication>): Promise<CreatorApplication>;
  verifyCreatorPayment(id: number, txHash: string, amount: string, currency: string): Promise<CreatorApplication>;
  
  // Session store
  sessionStore: session.Store;
}

class DatabaseStorage implements IStorage {
  sessionStore: session.Store;
  
  constructor() {
    // Use in-memory session store for simplicity
    this.sessionStore = new session.MemoryStore();
  }
  
  async getUser(id: number): Promise<User> {
    const result = await db.query.users.findFirst({
      where: eq(users.id, id)
    });
    
    if (!result) {
      throw new Error(`User with id ${id} not found`);
    }
    
    return result;
  }
  
  async getUserByUsername(username: string): Promise<User | undefined> {
    return await db.query.users.findFirst({
      where: eq(users.username, username)
    });
  }
  
  async getUserByWalletAddress(address: string): Promise<User | undefined> {
    return await db.query.users.findFirst({
      where: eq(users.wallet_address, address)
    });
  }
  
  async getAllUsers(): Promise<User[]> {
    return await db.query.users.findMany({
      orderBy: [desc(users.created_at)]
    });
  }
  
  async generateNonce(wallet: string): Promise<string> {
    const nonce = randomBytes(32).toString('hex');
    
    // Check if user with wallet exists
    const user = await this.getUserByWalletAddress(wallet);
    
    if (user) {
      // Update existing user with new nonce
      await this.updateUser(user.id, { nonce });
    } else {
      // Create new user with wallet and nonce
      await this.createUser({
        username: `wallet_${wallet.substring(0, 8)}`,
        wallet_address: wallet,
        nonce,
        isAdmin: wallet.toLowerCase() === '0x14b66774d1eec557ff19dd637a0208a098c017be'.toLowerCase()
      });
    }
    
    return nonce;
  }
  
  async createUser(userData: any): Promise<User> {
    // Ensure saved_tasks and completed_tasks are arrays
    if (!userData.saved_tasks) userData.saved_tasks = [];
    if (!userData.completed_tasks) userData.completed_tasks = [];
    
    const [user] = await db.insert(users).values(userData).returning();
    return user;
  }
  
  async createUserWithPassword(userData: { username: string; password: string; isAdmin: boolean }): Promise<User> {
    // Import bcrypt
    const bcrypt = await import('bcrypt');
    
    // Hash the password
    const hashedPassword = await bcrypt.hash(userData.password, 10);
    
    // Create user with hashed password
    const newUser = {
      username: userData.username,
      password: hashedPassword,
      isAdmin: userData.isAdmin,
      saved_tasks: [],
      completed_tasks: []
    };
    
    const [user] = await db.insert(users).values(newUser).returning();
    return user;
  }
  
  async updateUser(id: number, data: Partial<User>): Promise<User> {
    const [updatedUser] = await db
      .update(users)
      .set(data)
      .where(eq(users.id, id))
      .returning();
      
    return updatedUser;
  }
  
  async updateUserPassword(id: number, currentPassword: string, newPassword: string): Promise<boolean> {
    // This method would normally hash passwords, but since we're using auth.ts for that,
    // we'll just verify the current password matches and then let auth.ts handle the update
    const user = await this.getUser(id);
    
    if (!user.password) {
      throw new Error("This user doesn't have a password set (Web3 login only)");
    }
    
    // auth.ts will handle the actual password comparison and update
    return true;
  }
  
  async getAllAirdrops(): Promise<Airdrops[]> {
    return await db.query.airdrops.findMany({
      orderBy: [desc(airdrops.created_at)]
    });
  }
  
  async getFeaturedAirdrops(limit: number = 4): Promise<Airdrops[]> {
    return await db.query.airdrops.findMany({
      where: eq(airdrops.status, "active"),
      orderBy: [desc(airdrops.views)],
      limit
    });
  }
  
  async getAirdropById(id: number): Promise<Airdrops | undefined> {
    return await db.query.airdrops.findFirst({
      where: eq(airdrops.id, id)
    });
  }
  
  async createAirdrop(airdropData: InsertAirdrops): Promise<Airdrops> {
    try {
      // Create a clean object without the tags property
      const { tags, ...cleanData } = airdropData;
      
      // This will hold our insert data
      const processedData: Record<string, any> = { ...cleanData };
      
      // Process tags
      // Force tags to be an array of strings
      let tagsArray: string[] = [];
      
      if (Array.isArray(tags)) {
        tagsArray = tags.map(tag => String(tag));
      } else if (tags) {
        // Handle single tag value
        tagsArray = [String(tags)];
      }
      
      processedData.tags = tagsArray;
      
      // Create a typed airdrop object using the processed data
      const typedAirdropData = {
        title: processedData.title,
        description: processedData.description,
        link: processedData.link,
        image_url: processedData.image_url,
        category_id: processedData.category_id,
        posted_by: processedData.posted_by,
        tags: processedData.tags,
        formattedDescription: processedData.formattedDescription,
        is_featured: processedData.is_featured ?? false,
        status: processedData.status ?? 'active'
      };
      
      const [airdrop] = await db.insert(airdrops).values(typedAirdropData).returning();
      return airdrop;
    } catch (error) {
      console.error("Error creating airdrop:", error);
      throw new Error("Failed to create airdrop");
    }
  }
  
  async updateAirdrop(id: number, data: Partial<InsertAirdrops>): Promise<Airdrops | undefined> {
    try {
      // Create a copy of the data without tags
      const { tags, ...cleanData } = data;
      
      // This will hold our update data
      const processedData: Record<string, any> = { ...cleanData };
      
      // Process tags if provided
      if (tags !== undefined) {
        // Force tags to be an array of strings
        let tagsArray: string[] = [];
        
        if (Array.isArray(tags)) {
          tagsArray = tags.map(tag => String(tag));
        } else if (tags) {
          // Handle single tag value
          tagsArray = [String(tags)];
        }
        
        processedData.tags = tagsArray;
      }
      
      // Create a properly typed update object
      const typedUpdateData: Partial<{
        title: string;
        description: string;
        link: string;
        image_url: string | null;
        category_id: number;
        posted_by: string;
        tags: string[];
        formattedDescription: string | null;
        is_featured: boolean;
        status: string;
        views: number;
      }> = {};
      
      // Only add fields that are present in processedData
      if ('title' in processedData) typedUpdateData.title = processedData.title;
      if ('description' in processedData) typedUpdateData.description = processedData.description;
      if ('link' in processedData) typedUpdateData.link = processedData.link;
      if ('image_url' in processedData) typedUpdateData.image_url = processedData.image_url;
      if ('category_id' in processedData) typedUpdateData.category_id = processedData.category_id;
      if ('posted_by' in processedData) typedUpdateData.posted_by = processedData.posted_by;
      if ('tags' in processedData) typedUpdateData.tags = processedData.tags;
      if ('formattedDescription' in processedData) typedUpdateData.formattedDescription = processedData.formattedDescription;
      if ('is_featured' in processedData) typedUpdateData.is_featured = processedData.is_featured;
      if ('status' in processedData) typedUpdateData.status = processedData.status;
      if ('views' in processedData) typedUpdateData.views = processedData.views;
      
      const [updatedAirdrop] = await db
        .update(airdrops)
        .set(typedUpdateData)
        .where(eq(airdrops.id, id))
        .returning();
        
      return updatedAirdrop;
    } catch (error) {
      console.error("Error updating airdrop:", error);
      throw new Error("Failed to update airdrop");
    }
  }
  
  async deleteAirdrop(id: number): Promise<void> {
    await db.delete(airdrops).where(eq(airdrops.id, id));
  }
  
  async incrementAirdropViews(id: number): Promise<void> {
    const airdrop = await this.getAirdropById(id);
    if (airdrop) {
      await db
        .update(airdrops)
        .set({ views: (airdrop.views || 0) + 1 })
        .where(eq(airdrops.id, id));
    }
  }
  
  async toggleSavedAirdrop(userId: number, airdropId: number): Promise<void> {
    const user = await this.getUser(userId);
    
    // Get current saved tasks array
    const savedTasks = user.saved_tasks || [];
    
    // Check if airdrop is already saved
    const index = savedTasks.indexOf(airdropId);
    
    if (index === -1) {
      // Add to saved tasks
      savedTasks.push(airdropId);
    } else {
      // Remove from saved tasks
      savedTasks.splice(index, 1);
    }
    
    // Update user
    await this.updateUser(userId, { saved_tasks: savedTasks });
  }
  
  async toggleCompletedAirdrop(userId: number, airdropId: number): Promise<void> {
    const user = await this.getUser(userId);
    
    // Get current completed tasks array
    const completedTasks = user.completed_tasks || [];
    
    // Check if airdrop is already completed
    const index = completedTasks.indexOf(airdropId);
    
    if (index === -1) {
      // Add to completed tasks
      completedTasks.push(airdropId);
    } else {
      // Remove from completed tasks
      completedTasks.splice(index, 1);
    }
    
    // Update user
    await this.updateUser(userId, { completed_tasks: completedTasks });
  }
  
  async subscribeToNewsletter(email: string): Promise<void> {
    try {
      // Check if email already exists
      const existingSubscription = await db.query.newsletters.findFirst({
        where: eq(newsletters.email, email)
      });
      
      if (!existingSubscription) {
        await db.insert(newsletters).values({
          email,
          subscribed_at: new Date() // Let Drizzle handle the date conversion
        });
      }
    } catch (error) {
      console.error("Error subscribing to newsletter:", error);
      throw new Error("Failed to subscribe to newsletter");
    }
  }
  
  async getNewsletterSubscribers(): Promise<Newsletter[]> {
    try {
      return await db.query.newsletters.findMany({
        orderBy: [desc(newsletters.subscribed_at)]
      });
    } catch (error) {
      console.error("Error getting newsletter subscribers:", error);
      throw new Error("Failed to get newsletter subscribers");
    }
  }
  
  // Category methods
  async getAllCategories(): Promise<Category[]> {
    return await db.query.categories.findMany({
      orderBy: [desc(categories.created_at)]
    });
  }
  
  async getCategoryById(id: number): Promise<Category | undefined> {
    return await db.query.categories.findFirst({
      where: eq(categories.id, id)
    });
  }
  
  async createCategory(categoryData: InsertCategory): Promise<Category> {
    const [category] = await db.insert(categories).values(categoryData).returning();
    return category;
  }
  
  async updateCategory(id: number, data: Partial<Category>): Promise<Category | undefined> {
    const [updatedCategory] = await db
      .update(categories)
      .set(data)
      .where(eq(categories.id, id))
      .returning();
      
    return updatedCategory;
  }
  
  async deleteCategory(id: number): Promise<void> {
    // Check if category has airdrops
    const airdropsWithCategory = await db.query.airdrops.findMany({
      where: eq(airdrops.category_id, id)
    });
    
    if (airdropsWithCategory.length > 0) {
      throw new Error("Cannot delete category with associated airdrops");
    }
    
    await db.delete(categories).where(eq(categories.id, id));
  }
  
  async getAirdropsByCategory(categoryId: number): Promise<Airdrops[]> {
    return await db.query.airdrops.findMany({
      where: eq(airdrops.category_id, categoryId),
      orderBy: [desc(airdrops.created_at)]
    });
  }
  
  // Site Settings methods
  async getSiteSettings(): Promise<SiteSettings> {
    // Get the first site settings record or create default one if none exists
    const settings = await db.query.siteSettings.findFirst();
    
    if (settings) {
      return settings;
    } else {
      const [newSettings] = await db.insert(siteSettings).values({
        site_name: "Crypto Airdrop Task Hub",
        site_description: "Discover and track crypto airdrops, tasks, and rewards.",
        creator_fee_currency: "USDT",
        creator_fee_amount: "10",
        creator_payment_address: "",
      }).returning();
      
      return newSettings;
    }
  }
  
  async updateSiteSettings(data: Partial<SiteSettings>): Promise<SiteSettings> {
    // Get existing settings
    let settings = await this.getSiteSettings();
    
    // Update settings
    const [updatedSettings] = await db
      .update(siteSettings)
      .set(data)
      .where(eq(siteSettings.id, settings.id))
      .returning();
      
    return updatedSettings;
  }
  
  async promoteToCreator(userId: number): Promise<User> {
    const user = await this.getUser(userId);
    
    if (user.isCreator) {
      throw new Error("User is already a creator");
    }
    
    const updatedUser = await this.updateUser(userId, { isCreator: true });
    return updatedUser;
  }
  
  async revokeCreatorStatus(userId: number): Promise<User> {
    const user = await this.getUser(userId);
    
    if (!user.isCreator) {
      throw new Error("User is not a creator");
    }
    
    const updatedUser = await this.updateUser(userId, { isCreator: false });
    return updatedUser;
  }
  
  async getCreatorApplications(): Promise<CreatorApplication[]> {
    return await db.query.creatorApplications.findMany({
      orderBy: [desc(creatorApplications.created_at)],
      with: {
        user: true,
        reviewer: true
      }
    });
  }
  
  async getUserCreatorApplications(userId: number): Promise<CreatorApplication[]> {
    return await db.query.creatorApplications.findMany({
      where: eq(creatorApplications.user_id, userId),
      orderBy: [desc(creatorApplications.created_at)]
    });
  }
  
  async getCreatorApplicationById(id: number): Promise<CreatorApplication | undefined> {
    return await db.query.creatorApplications.findFirst({
      where: eq(creatorApplications.id, id),
      with: {
        user: true,
        reviewer: true
      }
    });
  }
  
  async createCreatorApplication(application: InsertCreatorApplication): Promise<CreatorApplication> {
    const [newApplication] = await db.insert(creatorApplications).values(application).returning();
    return newApplication;
  }
  
  async updateCreatorApplication(id: number, data: Partial<CreatorApplication>): Promise<CreatorApplication> {
    const [updatedApplication] = await db
      .update(creatorApplications)
      .set(data)
      .where(eq(creatorApplications.id, id))
      .returning();
    
    return updatedApplication;
  }
  
  async verifyCreatorPayment(id: number, txHash: string, amount: string, currency: string): Promise<CreatorApplication> {
    const application = await this.getCreatorApplicationById(id);
    
    if (!application) {
      throw new Error("Creator application not found");
    }
    
    if (application.status !== "payment_pending") {
      throw new Error(`Application is in ${application.status} state, not payment_pending`);
    }
    
    // Update application with payment info but don't auto-approve
    // Instead set status to 'pending_review' for admin verification
    const updatedApplication = await this.updateCreatorApplication(id, {
      payment_tx_hash: txHash,
      payment_amount: amount,
      payment_currency: currency,
      status: "pending_review" // Status for admin to verify payment
    });
    
    // No longer auto-promote user to creator
    // This will be done by admin upon approval
    
    return updatedApplication;
  }
}

export const storage = new DatabaseStorage();
