import { Badge } from "@/components/ui/badge";
import { formatCurrency } from "@/lib/utils";

interface CryptoCardProps {
  coin: {
    id: string;
    name: string;
    symbol: string;
    current_price: number;
    price_change_percentage_24h: number;
    market_cap_rank: number;
    image: string;
  };
}

export default function CryptoCard({ coin }: CryptoCardProps) {
  const priceChange = coin.price_change_percentage_24h;
  const isPositive = priceChange >= 0;

  return (
    <div className="crypto-card bg-card rounded-xl p-4 shadow hover:shadow-lg">
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center">
          <div className="w-8 h-8 mr-3 rounded-full bg-background flex items-center justify-center overflow-hidden">
            <img src={coin.image} alt={coin.name} className="h-6 w-6" />
          </div>
          <div>
            <h3 className="font-semibold text-white">{coin.name}</h3>
            <span className="text-xs text-gray-400">{coin.symbol.toUpperCase()}</span>
          </div>
        </div>
        <Badge variant="outline" className="text-xs font-mono">#{coin.market_cap_rank}</Badge>
      </div>
      <div className="flex justify-between items-end">
        <span className="text-xl font-bold text-white">{formatCurrency(coin.current_price)}</span>
        <span className={`text-sm font-medium ${isPositive ? 'text-secondary' : 'text-destructive'}`}>
          {isPositive ? "+" : ""}{priceChange.toFixed(2)}%
        </span>
      </div>
    </div>
  );
}
