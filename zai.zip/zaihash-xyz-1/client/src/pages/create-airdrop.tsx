import { useState, useEffect } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Helmet } from "react-helmet";
import { useAuth } from "@/hooks/use-auth";
import { apiRequest, queryClient } from "@/lib/queryClient";
import Sidebar from "@/components/layout/sidebar";
import { useToast } from "@/hooks/use-toast";
import { InsertAirdrops, Category } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { AlertCircle, Loader2 } from "lucide-react";
import { AirdropStepEditor, AirdropStep } from "@/components/admin/airdrop-step-editor";

// Function to convert steps to HTML format
const formatStepsToHTML = (steps: AirdropStep[]): string => {
  const htmlSteps = steps.map((step, index) => {
    let stepHtml = `<div class="step">
<h3>Step ${index + 1}</h3>
<p>${step.content}</p>`;
    
    // Handle legacy single image
    if (step.imageUrl) {
      stepHtml += `\n<img src="${step.imageUrl}" alt="Step ${index + 1}" />`;
    }
    
    // Handle multiple images if present
    if (step.imageUrls && step.imageUrls.length > 0) {
      step.imageUrls.forEach((imgUrl, imgIndex) => {
        // Skip the first image if it's already added via imageUrl
        if (imgIndex === 0 && imgUrl === step.imageUrl) return;
        stepHtml += `\n<img src="${imgUrl}" alt="Step ${index + 1} Image ${imgIndex + 1}" />`;
      });
    }
    
    stepHtml += '\n</div>';
    return stepHtml;
  });

  return htmlSteps.join('\n\n');
};

// Function to try parsing existing HTML steps into the step format
const tryParseExistingSteps = (html: string): AirdropStep[] => {
  try {
    // Create a simple parser for the HTML format used
    const stepRegex = /<div class="step">([\s\S]*?)<\/div>/g;
    const contentRegex = /<p>([\s\S]*?)<\/p>/;
    const imageRegex = /<img src="([\s\S]*?)" alt="[^"]*" \/>/g;
    
    const steps: AirdropStep[] = [];
    let match;
    
    while ((match = stepRegex.exec(html)) !== null) {
      const stepHtml = match[1];
      
      // Extract content
      const contentMatch = contentRegex.exec(stepHtml);
      const content = contentMatch ? contentMatch[1].trim() : '';
      
      // Extract all images
      const imageUrls: string[] = [];
      let imageMatch;
      
      // Reset lastIndex before using regex again
      imageRegex.lastIndex = 0;
      
      while ((imageMatch = imageRegex.exec(stepHtml)) !== null) {
        imageUrls.push(imageMatch[1]);
      }
      
      // Create the step with both single image and multiple images
      steps.push({ 
        content, 
        imageUrl: imageUrls.length > 0 ? imageUrls[0] : undefined,
        imageUrls: imageUrls.length > 0 ? imageUrls : [] 
      });
    }
    
    return steps.length > 0 ? steps : [{ content: html || "", imageUrl: undefined, imageUrls: [] }];
  } catch (error) {
    // If parsing fails, return a single step with all the content
    console.error('Error parsing HTML steps:', error);
    return [{ content: html || "", imageUrl: undefined, imageUrls: [] }];
  }
};

export default function CreateAirdropPage() {
  const [, navigate] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  
  const [formData, setFormData] = useState<Partial<InsertAirdrops>>({
    title: "",
    description: "",
    tags: [],
    link: "",
    potential_profit: "",
    status: "active",
    category_id: undefined,
  });
  
  const [currentTag, setCurrentTag] = useState("");
  const [errors, setErrors] = useState<Record<string, string>>({});
  
  // Fetch categories for the dropdown
  const { data: categories, isLoading: categoriesLoading } = useQuery<Category[]>({
    queryKey: ["/api/categories"],
  });
  
  const createAirdropMutation = useMutation({
    mutationFn: async (data: InsertAirdrops) => {
      const res = await apiRequest("POST", "/api/airdrops", data);
      return await res.json();
    },
    onSuccess: (data) => {
      queryClient.invalidateQueries({ queryKey: ["/api/airdrops"] });
      queryClient.invalidateQueries({ queryKey: ["/api/airdrops/featured"] });
      toast({
        title: "Airdrop created",
        description: "Your airdrop tutorial has been successfully created.",
      });
      // Navigate back to airdrops
      navigate("/airdrops");
    },
    onError: (error: Error) => {
      toast({
        title: "Error creating airdrop",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Check if user is creator
  useEffect(() => {
    if (user && !user.isCreator && !user.isAdmin) {
      toast({
        title: "Creator Privileges Required",
        description: "You need to be a creator to post airdrops.",
        variant: "destructive",
      });
      navigate("/profile");
    }
  }, [user, navigate, toast]);
  
  const validateForm = () => {
    const newErrors: Record<string, string> = {};
    
    if (!formData.title?.trim()) {
      newErrors.title = "Title is required";
    }
    
    if (!formData.description?.trim()) {
      newErrors.description = "Description is required";
    }
    
    if (!formData.tags || formData.tags.length === 0) {
      newErrors.tags = "At least one tag is required";
    }
    
    if (formData.link && !isValidUrl(formData.link)) {
      newErrors.link = "Please enter a valid URL";
    }
    
    if (!formData.category_id) {
      newErrors.category_id = "Please select a category";
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };
  
  const isValidUrl = (string: string) => {
    try {
      new URL(string);
      return true;
    } catch (_) {
      return false;
    }
  };
  
  const handleAddTag = () => {
    if (currentTag.trim() && formData.tags && !formData.tags.includes(currentTag.trim())) {
      setFormData({
        ...formData,
        tags: [...(formData.tags || []), currentTag.trim()],
      });
      setCurrentTag("");
    }
  };
  
  const handleRemoveTag = (tagToRemove: string) => {
    if (formData.tags) {
      setFormData({
        ...formData,
        tags: formData.tags.filter(tag => tag !== tagToRemove),
      });
    }
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!validateForm()) return;
    
    // Don't pass created_at and updated_at - they have database defaults
    createAirdropMutation.mutate({
      title: formData.title || "",
      description: formData.description || "",
      tags: formData.tags || [],
      link: formData.link || "",
      status: formData.status || "active",
      views: 0,
      category_id: formData.category_id,
      posted_by: user?.username || "",
    });
  };
  
  if (!user || (!user.isCreator && !user.isAdmin)) {
    return (
      <div className="min-h-screen flex flex-col md:flex-row">
        <Helmet>
          <title>Creator Access Required</title>
          <meta name="description" content="Creator access is required to post airdrops." />
        </Helmet>
        
        <Sidebar />
        
        <main className="flex-1 p-6 flex items-center justify-center">
          <Card className="w-full max-w-md">
            <CardHeader>
              <CardTitle>Creator Access Required</CardTitle>
              <CardDescription>
                You need to be a verified creator to post airdrops.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                Please go to your profile and apply for creator status to gain access to this feature.
              </p>
              <Button onClick={() => navigate("/profile")} className="w-full">
                Go to Profile
              </Button>
            </CardContent>
          </Card>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <Helmet>
        <title>Create Airdrop</title>
        <meta name="description" content="Create a new airdrop tutorial or task for users." />
      </Helmet>
      
      <Sidebar />
      
      <main className="flex-1 p-6 md:p-10">
        <div className="max-w-3xl mx-auto">
          <div className="mb-8">
            <Button 
              variant="outline" 
              size="sm" 
              onClick={() => navigate("/airdrops")}
              className="mb-4"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M10 19l-7-7m0 0l7-7m-7 7h18" />
              </svg>
              Back to Airdrops
            </Button>
            
            <h1 className="text-3xl font-bold text-white">Create New Airdrop</h1>
            <p className="text-gray-400 mt-2">
              Add a new airdrop tutorial or task for users to complete.
            </p>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>Airdrop Details</CardTitle>
              <CardDescription>Fill in the details for the new airdrop tutorial</CardDescription>
            </CardHeader>
            <form onSubmit={handleSubmit}>
              <CardContent className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="title">Title</Label>
                  <Input 
                    id="title"
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    placeholder="e.g., ZetaChain Testnet Airdrop"
                  />
                  {errors.title && (
                    <p className="text-destructive text-sm">{errors.title}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="description">Tutorial Steps</Label>
                  <AirdropStepEditor
                    steps={
                      // If formData.description already exists, try to parse it, otherwise start with an empty array
                      formData.description 
                        ? tryParseExistingSteps(formData.description) 
                        : []
                    }
                    onChange={(steps) => {
                      const formattedHTML = formatStepsToHTML(steps);
                      setFormData({ ...formData, description: formattedHTML });
                    }}
                    endpoint="/api/upload/airdrop-image"
                  />
                  {errors.description && (
                    <p className="text-destructive text-sm">{errors.description}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label>Tags</Label>
                  <div className="flex space-x-2">
                    <Input 
                      value={currentTag}
                      onChange={(e) => setCurrentTag(e.target.value)}
                      placeholder="Add a tag"
                      className="flex-1"
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') {
                          e.preventDefault();
                          handleAddTag();
                        }
                      }}
                    />
                    <Button 
                      type="button" 
                      variant="secondary"
                      onClick={handleAddTag}
                    >
                      Add Tag
                    </Button>
                  </div>
                  {errors.tags && (
                    <p className="text-destructive text-sm">{errors.tags}</p>
                  )}
                  <div className="flex flex-wrap gap-2 mt-2">
                    {formData.tags && formData.tags.map((tag, index) => (
                      <Badge key={index} variant="secondary" className="gap-1">
                        {tag}
                        <button 
                          type="button" 
                          className="ml-1 hover:text-destructive focus:outline-none"
                          onClick={() => handleRemoveTag(tag)}
                        >
                          <svg xmlns="http://www.w3.org/2000/svg" className="h-3 w-3" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                          </svg>
                          <span className="sr-only">Remove tag</span>
                        </button>
                      </Badge>
                    ))}
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="link">External Link (Optional)</Label>
                  <Input 
                    id="link"
                    value={formData.link || ""}
                    onChange={(e) => setFormData({ ...formData, link: e.target.value })}
                    placeholder="https://example.com/airdrop"
                  />
                  {errors.link && (
                    <p className="text-destructive text-sm">{errors.link}</p>
                  )}
                </div>

                <div className="space-y-2">
                  <Label htmlFor="potential_profit">Potential Profit (Optional)</Label>
                  <Input 
                    id="potential_profit"
                    value={formData.potential_profit || ""}
                    onChange={(e) => setFormData({ ...formData, potential_profit: e.target.value })}
                    placeholder="e.g., $10 - $1000"
                  />
                  {errors.potential_profit && (
                    <p className="text-destructive text-sm">{errors.potential_profit}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="category">Category</Label>
                  <Select 
                    value={formData.category_id?.toString()} 
                    onValueChange={(value) => setFormData({ ...formData, category_id: parseInt(value, 10) })}
                  >
                    <SelectTrigger id="category">
                      <SelectValue placeholder="Select a category" />
                    </SelectTrigger>
                    <SelectContent>
                      {categoriesLoading ? (
                        <div className="flex items-center justify-center p-2">
                          <Loader2 className="h-4 w-4 animate-spin mr-2" />
                          <span>Loading categories...</span>
                        </div>
                      ) : categories && categories.length > 0 ? (
                        categories.map(category => (
                          <SelectItem key={category.id} value={category.id.toString()}>
                            {category.name}
                          </SelectItem>
                        ))
                      ) : (
                        <SelectItem value="no-categories" disabled>
                          No categories available
                        </SelectItem>
                      )}
                    </SelectContent>
                  </Select>
                  {errors.category_id && (
                    <p className="text-destructive text-sm">{errors.category_id}</p>
                  )}
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="status">Status</Label>
                  <Select 
                    defaultValue={formData.status}
                    onValueChange={(value) => setFormData({ ...formData, status: value })}
                  >
                    <SelectTrigger id="status">
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">Active</SelectItem>
                      <SelectItem value="draft">Draft</SelectItem>
                      <SelectItem value="closed">Closed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                
                {createAirdropMutation.error && (
                  <Alert variant="destructive">
                    <AlertCircle className="h-4 w-4" />
                    <AlertDescription>
                      {createAirdropMutation.error.message}
                    </AlertDescription>
                  </Alert>
                )}
              </CardContent>
              <CardFooter className="flex justify-between">
                <Button 
                  type="button" 
                  variant="outline"
                  onClick={() => navigate("/airdrops")}
                >
                  Cancel
                </Button>
                <Button 
                  type="submit"
                  disabled={createAirdropMutation.isPending}
                >
                  {createAirdropMutation.isPending ? "Creating..." : "Create Airdrop"}
                </Button>
              </CardFooter>
            </form>
          </Card>
        </div>
      </main>
    </div>
  );
}