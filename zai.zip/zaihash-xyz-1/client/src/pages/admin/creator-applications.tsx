import React, { useState } from "react";
import { Helmet } from "react-helmet";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { CreatorApplication } from "@shared/schema";
import { getQueryFn, apiRequest } from "@/lib/queryClient";
import Sidebar from "@/components/layout/sidebar";
import { useToast } from "@/hooks/use-toast";

import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Card,
  CardContent,
} from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Clock, 
  Check, 
  X, 
  DollarSign, 
  ExternalLink,
  FolderOpen, 
  Loader2,
  MessageSquare,
  Eye
} from "lucide-react";

interface ExtendedCreatorApplication extends CreatorApplication {
  rejection_reason?: string;
  tx_hash?: string; // For backward compatibility
  user?: {
    id: number;
    username: string;
    isAdmin: boolean;
    isCreator: boolean;
  };
  reviewer?: {
    id: number;
    username: string;
    isAdmin: boolean;
  };
}

export default function CreatorApplicationsPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [rejectReason, setRejectReason] = useState("");
  const [selectedApplication, setSelectedApplication] = useState<ExtendedCreatorApplication | null>(null);
  const [verifyDialogOpen, setVerifyDialogOpen] = useState(false);

  // Get all creator applications
  const { data: applications, isLoading } = useQuery<ExtendedCreatorApplication[]>({
    queryKey: ["/api/admin/creator-applications"],
    queryFn: getQueryFn({ on401: "throw" }),
  });

  // Accept application mutation
  const approveMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("POST", `/api/admin/creator-applications/${id}/approve`);
    },
    onSuccess: () => {
      toast({
        title: "Application Approved",
        description: "The creator application has been approved successfully.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/creator-applications"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to approve application",
        variant: "destructive",
      });
    },
  });

  // Reject application mutation
  const rejectMutation = useMutation({
    mutationFn: async ({ id, reason }: { id: number; reason: string }) => {
      await apiRequest("POST", `/api/admin/creator-applications/${id}/reject`, { reason });
    },
    onSuccess: () => {
      toast({
        title: "Application Rejected",
        description: "The creator application has been rejected.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/creator-applications"] });
      setRejectReason("");
      setSelectedApplication(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to reject application",
        variant: "destructive",
      });
    },
  });
  
  // Verify payment mutation
  const verifyPaymentMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("POST", `/api/admin/creator-applications/${id}/approve`);
    },
    onSuccess: () => {
      toast({
        title: "Payment Verified",
        description: "The creator payment has been verified and the application approved.",
      });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/creator-applications"] });
      queryClient.invalidateQueries({ queryKey: ["/api/admin/users"] });
      setVerifyDialogOpen(false);
      setSelectedApplication(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to verify payment",
        variant: "destructive",
      });
    },
  });

  // Handle approve button click
  const handleApprove = (application: ExtendedCreatorApplication) => {
    // For payment pending or pending review applications with tx hash, open verification dialog
    if ((application.status === 'payment_pending' || application.status === 'pending_review') && application.payment_tx_hash) {
      setSelectedApplication(application);
      setVerifyDialogOpen(true);
    } else {
      approveMutation.mutate(application.id);
    }
  };
  
  // Handle verify payment
  const handleVerifyPayment = () => {
    if (!selectedApplication) return;
    verifyPaymentMutation.mutate(selectedApplication.id);
  };

  // Handle reject confirmation
  const handleReject = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedApplication) return;
    
    if (rejectReason.trim().length < 5) {
      toast({
        title: "Validation Error",
        description: "Please provide a more detailed reason for rejection.",
        variant: "destructive",
      });
      return;
    }

    rejectMutation.mutate({
      id: selectedApplication.id,
      reason: rejectReason,
    });
  };

  // Helper for status badges
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'pending':
        return <span className="px-2 py-1 rounded-full text-xs bg-yellow-100 text-yellow-800">Pending</span>;
      case 'payment_pending':
        return <span className="px-2 py-1 rounded-full text-xs bg-blue-100 text-blue-800">Payment Pending</span>;
      case 'pending_review':
        return <span className="px-2 py-1 rounded-full text-xs bg-orange-100 text-orange-800">Payment Submitted</span>;
      case 'approved':
        return <span className="px-2 py-1 rounded-full text-xs bg-green-100 text-green-800">Approved</span>;
      case 'rejected':
        return <span className="px-2 py-1 rounded-full text-xs bg-red-100 text-red-800">Rejected</span>;
      default:
        return <span className="px-2 py-1 rounded-full text-xs bg-gray-100 text-gray-800">{status}</span>;
    }
  };

  // Format date helper
  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString();
  };

  return (
    <div className="min-h-screen flex flex-col md:flex-row">
      <Sidebar />
      
      <main className="flex-1 overflow-x-hidden">
        <div className="container py-8 px-4">
          <Helmet>
            <title>Creator Applications Management - Admin Dashboard</title>
          </Helmet>
          
          <div className="flex items-center justify-between mb-6">
            <div>
              <h1 className="text-3xl font-bold">Creator Applications</h1>
              <p className="text-muted-foreground">Manage creator applications and approve/reject requests</p>
            </div>
          </div>
          
          <Tabs defaultValue="pending" className="w-full">
            <TabsList className="mb-6">
              <TabsTrigger value="pending">
                <Clock className="mr-2 h-4 w-4" />
                Pending
              </TabsTrigger>
              <TabsTrigger value="payment">
                <DollarSign className="mr-2 h-4 w-4" />
                Payment Pending
              </TabsTrigger>
              <TabsTrigger value="review">
                <Eye className="mr-2 h-4 w-4" />
                Payment Review
              </TabsTrigger>
              <TabsTrigger value="approved">
                <Check className="mr-2 h-4 w-4" />
                Approved
              </TabsTrigger>
              <TabsTrigger value="rejected">
                <X className="mr-2 h-4 w-4" />
                Rejected
              </TabsTrigger>
            </TabsList>
            
            {isLoading ? (
              <div className="flex justify-center py-8">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
              </div>
            ) : applications && applications.length > 0 ? (
              <>
                <TabsContent value="pending">
                  <ApplicationTable 
                    applications={applications.filter(app => app.status === 'pending')}
                    onApprove={handleApprove}
                    onReject={(app) => setSelectedApplication(app)}
                    getStatusBadge={getStatusBadge}
                    formatDate={formatDate}
                  />
                </TabsContent>
                
                <TabsContent value="payment">
                  <ApplicationTable 
                    applications={applications.filter(app => app.status === 'payment_pending')}
                    onApprove={handleApprove}
                    onReject={(app) => setSelectedApplication(app)}
                    getStatusBadge={getStatusBadge}
                    formatDate={formatDate}
                  />
                </TabsContent>
                
                <TabsContent value="review">
                  <ApplicationTable 
                    applications={applications.filter(app => app.status === 'pending_review')}
                    onApprove={handleApprove}
                    onReject={(app) => setSelectedApplication(app)}
                    getStatusBadge={getStatusBadge}
                    formatDate={formatDate}
                  />
                </TabsContent>
                
                <TabsContent value="approved">
                  <ApplicationTable 
                    applications={applications.filter(app => app.status === 'approved')}
                    onApprove={handleApprove}
                    onReject={(app) => setSelectedApplication(app)}
                    getStatusBadge={getStatusBadge}
                    formatDate={formatDate}
                  />
                </TabsContent>
                
                <TabsContent value="rejected">
                  <ApplicationTable 
                    applications={applications.filter(app => app.status === 'rejected')}
                    onApprove={handleApprove}
                    onReject={(app) => setSelectedApplication(app)}
                    getStatusBadge={getStatusBadge}
                    formatDate={formatDate}
                  />
                </TabsContent>
              </>
            ) : (
              <Card>
                <CardContent className="py-10 text-center">
                  <FolderOpen className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
                  <p className="text-muted-foreground">No applications found.</p>
                </CardContent>
              </Card>
            )}
          </Tabs>
          
          {/* Reject Reason Dialog */}
          {selectedApplication && !verifyDialogOpen && (
            <Dialog open={!!selectedApplication && !verifyDialogOpen} onOpenChange={(open) => !open && setSelectedApplication(null)}>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Reject Creator Application</DialogTitle>
                  <DialogDescription>
                    Provide a reason for rejecting this application. This will be visible to the user.
                  </DialogDescription>
                </DialogHeader>
                
                <form onSubmit={handleReject}>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <p className="text-sm font-medium">
                        Application from: {selectedApplication.user?.username || ''} 
                        <span className="text-xs text-muted-foreground ml-1">
                          (ID: {selectedApplication.user_id})
                        </span>
                      </p>
                      <p className="text-sm">Submitted: {formatDate(selectedApplication.created_at.toString())}</p>
                    </div>
                    
                    <ScrollArea className="max-h-[100px] border p-2 rounded-md">
                      <div className="p-2">
                        <p className="text-sm font-medium">Application Reason:</p>
                        <p className="text-sm">{selectedApplication.reason}</p>
                      </div>
                    </ScrollArea>
                    
                    <div className="space-y-2">
                      <p className="text-sm font-medium">Rejection Reason:</p>
                      <Textarea 
                        placeholder="Please explain why this application is being rejected..."
                        value={rejectReason}
                        onChange={(e) => setRejectReason(e.target.value)}
                        className="min-h-[100px]"
                        required
                      />
                    </div>
                  </div>
                  
                  <DialogFooter>
                    <Button type="button" variant="outline" onClick={() => setSelectedApplication(null)}>
                      Cancel
                    </Button>
                    <Button type="submit" variant="destructive" disabled={rejectMutation.isPending}>
                      {rejectMutation.isPending ? (
                        <>
                          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                          Rejecting...
                        </>
                      ) : (
                        <>
                          <X className="mr-2 h-4 w-4" />
                          Reject Application
                        </>
                      )}
                    </Button>
                  </DialogFooter>
                </form>
              </DialogContent>
            </Dialog>
          )}
          
          {/* Verify Payment Dialog */}
          {selectedApplication && (
            <Dialog open={verifyDialogOpen} onOpenChange={setVerifyDialogOpen}>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Verify Creator Payment</DialogTitle>
                  <DialogDescription>
                    Verify the cryptocurrency payment for this creator application.
                  </DialogDescription>
                </DialogHeader>
                
                <div className="space-y-4 py-4">
                  <div className="space-y-2">
                    <p className="text-sm font-medium">
                      Application from: {selectedApplication.user?.username || ''} 
                      <span className="text-xs text-muted-foreground ml-1">
                        (ID: {selectedApplication.user_id})
                      </span>
                    </p>
                    <p className="text-sm">Submitted: {formatDate(selectedApplication.created_at.toString())}</p>
                  </div>
                  
                  {selectedApplication.payment_tx_hash && (
                    <div className="border rounded-md p-4 bg-blue-50">
                      <p className="text-sm font-medium flex items-center text-blue-700">
                        <DollarSign className="h-4 w-4 mr-1" />
                        Payment Information
                      </p>
                      
                      <div className="mt-3 space-y-3">
                        <div>
                          <p className="text-xs font-medium text-gray-500">Amount:</p>
                          <p className="text-sm font-medium">
                            {selectedApplication.payment_amount} {selectedApplication.payment_currency}
                          </p>
                        </div>
                        
                        <div>
                          <p className="text-xs font-medium text-gray-500">Transaction Hash:</p>
                          <div className="flex items-center mt-1">
                            <p className="text-xs font-mono bg-blue-100 p-1 rounded overflow-auto max-w-[300px]">
                              {selectedApplication.payment_tx_hash}
                            </p>
                            <a 
                              href={`https://etherscan.io/tx/${selectedApplication.payment_tx_hash}`}
                              target="_blank"
                              rel="noopener noreferrer" 
                              className="ml-2 text-blue-600 hover:text-blue-800"
                            >
                              <ExternalLink className="h-4 w-4" />
                            </a>
                          </div>
                        </div>
                        
                        <div className="pt-2 mt-2 border-t border-blue-200">
                          <p className="text-sm font-medium text-blue-700">Payment Verification:</p>
                          <p className="text-xs text-gray-600 mt-1">
                            Please verify that the transaction is valid and complete before approving
                            this creator application. This will grant creator privileges to the user.
                          </p>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
                
                <DialogFooter>
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => {
                      setVerifyDialogOpen(false);
                      setSelectedApplication(null);
                    }}
                  >
                    Cancel
                  </Button>
                  
                  <Button
                    type="button"
                    className="bg-blue-600 hover:bg-blue-700"
                    onClick={handleVerifyPayment}
                    disabled={verifyPaymentMutation.isPending}
                  >
                    {verifyPaymentMutation.isPending ? (
                      <>
                        <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                        Verifying...
                      </>
                    ) : (
                      <>
                        <Check className="mr-2 h-4 w-4" />
                        Verify and Approve
                      </>
                    )}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          )}
        </div>
      </main>
    </div>
  );
}

interface ApplicationTableProps {
  applications: ExtendedCreatorApplication[];
  onApprove: (application: ExtendedCreatorApplication) => void;
  onReject: (application: ExtendedCreatorApplication) => void;
  getStatusBadge: (status: string) => React.ReactNode;
  formatDate: (dateString: string) => string;
}

function ApplicationTable({ applications, onApprove, onReject, getStatusBadge, formatDate }: ApplicationTableProps) {
  return (
    <Card>
      <CardContent className="p-0">
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>ID</TableHead>
              <TableHead>User</TableHead>
              <TableHead>Date Submitted</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Payment</TableHead>
              <TableHead>Actions</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {applications.map((application) => (
              <TableRow key={application.id}>
                <TableCell className="font-medium">{application.id}</TableCell>
                <TableCell>
                  {application.user ? (
                    <div className="flex items-center space-x-2">
                      <span>{application.user.username}</span>
                      <span className="text-xs text-muted-foreground">({application.user_id})</span>
                    </div>
                  ) : (
                    <span>{application.user_id}</span>
                  )}
                </TableCell>
                <TableCell>{formatDate(application.created_at.toString())}</TableCell>
                <TableCell>{getStatusBadge(application.status)}</TableCell>
                <TableCell>
                  {application.payment_tx_hash ? (
                    <div className="flex items-center space-x-2">
                      <DollarSign className="h-4 w-4 text-green-500" />
                      <span 
                        className="text-xs font-mono truncate max-w-[120px]" 
                        title={application.payment_tx_hash}
                      >
                        {application.payment_tx_hash.substring(0, 8)}...
                        {application.payment_tx_hash.substring(application.payment_tx_hash.length - 8)}
                      </span>
                    </div>
                  ) : (
                    <span className="text-sm text-muted-foreground">No payment</span>
                  )}
                </TableCell>
                <TableCell>
                  <div className="flex items-center space-x-2">
                    <Dialog>
                      <DialogTrigger asChild>
                        <Button variant="outline" size="sm">
                          <MessageSquare className="h-4 w-4 mr-1" />
                          View
                        </Button>
                      </DialogTrigger>
                      <DialogContent>
                        <DialogHeader>
                          <DialogTitle>Application Details</DialogTitle>
                        </DialogHeader>
                        <div className="space-y-4 py-4">
                          <div className="grid grid-cols-2 gap-4">
                            <div>
                              <p className="text-sm font-medium">User:</p>
                              <p className="text-sm">
                                {application.user ? application.user.username : ''} 
                                <span className="text-xs text-muted-foreground ml-1">
                                  (ID: {application.user_id})
                                </span>
                              </p>
                            </div>
                            <div>
                              <p className="text-sm font-medium">Status:</p>
                              <p className="text-sm">{getStatusBadge(application.status)}</p>
                            </div>
                            <div>
                              <p className="text-sm font-medium">Submitted:</p>
                              <p className="text-sm">{formatDate(application.created_at.toString())}</p>
                            </div>
                            <div>
                              <p className="text-sm font-medium">Last Updated:</p>
                              <p className="text-sm">{formatDate(application.updated_at.toString())}</p>
                            </div>
                          </div>
                          
                          {application.payment_tx_hash && (
                            <div className="border rounded-md p-3 bg-slate-50">
                              <p className="text-sm font-medium flex items-center">
                                <DollarSign className="h-4 w-4 mr-1 text-green-600" />
                                Payment Information
                              </p>
                              <div className="space-y-2 mt-2">
                                <div className="flex justify-between items-center">
                                  <p className="text-xs">
                                    <span className="font-medium">Amount:</span> {application.payment_amount} {application.payment_currency}
                                  </p>
                                  <a 
                                    href={`https://etherscan.io/tx/${application.payment_tx_hash}`}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="text-xs text-blue-600 hover:underline flex items-center"
                                  >
                                    View on Etherscan
                                    <ExternalLink className="h-3 w-3 ml-1" />
                                  </a>
                                </div>
                                <div>
                                  <p className="text-xs mb-1">
                                    <span className="font-medium">Transaction Hash:</span>
                                  </p>
                                  <div className="bg-slate-100 p-2 rounded text-xs font-mono break-all border border-slate-200">
                                    {application.payment_tx_hash}
                                  </div>
                                </div>
                                {(application.status === 'payment_pending' || application.status === 'pending_review') && (
                                  <div className="mt-3 pt-2 border-t border-slate-200">
                                    <p className="text-xs mb-2 font-medium text-slate-600">Manual Verification Required:</p>
                                    <Button 
                                      className="w-full"
                                      size="sm"
                                      onClick={() => onApprove(application)}
                                    >
                                      <Check className="h-4 w-4 mr-1" />
                                      Verify Payment & Approve Creator
                                    </Button>
                                  </div>
                                )}
                              </div>
                            </div>
                          )}
                          
                          <div>
                            <p className="text-sm font-medium">Application Reason:</p>
                            <ScrollArea className="max-h-[150px] border p-2 rounded-md mt-1">
                              <p className="text-sm whitespace-pre-wrap p-2">{application.reason}</p>
                            </ScrollArea>
                          </div>
                        </div>
                      </DialogContent>
                    </Dialog>
                    
                    {application.status === 'pending' || application.status === 'payment_pending' || application.status === 'pending_review' ? (
                      <>
                        <Button 
                          variant="default" 
                          size="sm"
                          onClick={() => onApprove(application)}
                          disabled={application.status === 'pending'}
                          title={application.status === 'pending' ? "User must submit payment first" : ""}
                        >
                          <Check className="h-4 w-4 mr-1" />
                          Approve
                        </Button>
                        <Button 
                          variant="destructive" 
                          size="sm"
                          onClick={() => onReject(application)}
                        >
                          <X className="h-4 w-4 mr-1" />
                          Reject
                        </Button>
                      </>
                    ) : null}
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </CardContent>
    </Card>
  );
}