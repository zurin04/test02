import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Helmet } from "react-helmet";
import LegalHeader from "@/components/layout/legal-header";

export default function Disclaimer() {
  return (
    <>
      <Helmet>
        <title>Disclaimer | AirdropVerse</title>
        <meta name="description" content="Important disclaimers regarding the use of AirdropVerse platform and cryptocurrency information." />
      </Helmet>
      
      <LegalHeader />
      
      <div className="container py-10 max-w-4xl mx-auto">
        <Card className="border-gray-800 shadow-lg">
          <CardHeader className="border-b border-gray-800">
            <CardTitle className="text-2xl font-bold">Disclaimer</CardTitle>
          </CardHeader>
          
          <CardContent className="pt-6 prose prose-invert max-w-none">
            <p className="text-sm text-gray-400">Last updated: May 10, 2025</p>
            
            <h2>General Disclaimer</h2>
            <p>
              The information provided on AirdropVerse is for general informational purposes only. While we strive to 
              keep the information up to date and correct, we make no representations or warranties of any kind, express or implied, 
              about the completeness, accuracy, reliability, suitability, or availability of the information, products, services, 
              or related graphics contained on the website for any purpose.
            </p>

            <h2>No Financial Advice</h2>
            <p>
              The content on AirdropVerse does not constitute financial advice, investment advice, trading advice, or any other sort of advice. 
              We do not recommend that any cryptocurrency should be bought, sold, or held by you. Nothing on this website should be taken 
              as an offer to buy, sell or hold a cryptocurrency. Do conduct your own due diligence and consult your financial advisor 
              before making any investment decisions.
            </p>

            <h2>Risk Warning</h2>
            <p>
              Cryptocurrency investments are subject to high market risk. The cryptocurrency market is volatile and unpredictable. 
              The value of digital assets can go up or down, and you could lose all of your capital. Past performance is not indicative 
              of future results. Before deciding to participate in cryptocurrency airdrops or investing in cryptocurrencies, carefully consider 
              your investment objectives, level of experience, and risk appetite.
            </p>

            <h2>No Endorsement</h2>
            <p>
              We do not endorse, guarantee, or vouch for any of the airdrops, tokens, or projects listed on our platform. 
              Listing of a project on AirdropVerse does not signify approval of the project's legitimacy or potential value. 
              We are not responsible for the actions, content, information, or data of third parties, including projects listed on our platform.
            </p>

            <h2>Security Risks</h2>
            <p>
              Participating in cryptocurrency airdrops and interacting with blockchain applications involves inherent security risks. 
              These risks include, but are not limited to, smart contract vulnerabilities, phishing attacks, wallet compromise, or other security breaches. 
              Always verify the authenticity of a project before connecting your wallet or sharing your information. 
              We are not responsible for any losses resulting from security vulnerabilities.
            </p>

            <h2>Taxation and Compliance</h2>
            <p>
              The regulatory treatment of cryptocurrencies and airdrops varies by jurisdiction. 
              It is your responsibility to ensure compliance with local laws and tax regulations. 
              Receiving airdrops may have tax implications in your jurisdiction. 
              We do not provide tax, legal, or accounting advice. 
              Consult with a professional advisor regarding your individual circumstances.
            </p>

            <h2>Accuracy of Information</h2>
            <p>
              While we make reasonable efforts to provide accurate information about airdrops and cryptocurrency projects, 
              we cannot guarantee that all information is current, complete, or accurate. 
              The cryptocurrency space evolves rapidly, and details about projects can change without notice. 
              Always verify information from official project sources before making decisions.
            </p>

            <h2>Third-Party Links</h2>
            <p>
              Our platform may contain links to external websites or services that are not operated by us. 
              We have no control over the content and practices of these sites and cannot accept responsibility 
              for their respective privacy policies or practices. You access such links at your own risk.
            </p>

            <h2>Limitation of Liability</h2>
            <p>
              To the maximum extent permitted by applicable law, we will not be liable for any indirect, incidental, 
              special, consequential, or punitive damages, including loss of profits, data, or use, 
              arising out of or in connection with your use of our platform or participation in airdrops listed on our platform.
            </p>

            <h2>Changes to This Disclaimer</h2>
            <p>
              We may update our Disclaimer from time to time. We will notify you of any changes by posting the new Disclaimer on this page.
            </p>

            <h2>Contact Us</h2>
            <p>
              If you have any questions about this Disclaimer, please contact us at:<br />
              Email: legal@airdropverse.com
            </p>
          </CardContent>
        </Card>
      </div>
    </>
  );
}